<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMusicasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('musicas', function (Blueprint $table) {
            $table->id();
            $table->string('nombre');  // Cambiado a string como ejemplo, puedes ajustar el tipo según tus necesidades
            $table->string('album');   // Cambiado a string como ejemplo
            $table->date('fecha');     // Cambiado a date como ejemplo
            $table->time('duracion');  // Cambiado a time como ejemplo
            $table->string('imagen');  // Cambiado a string como ejemplo
            $table->timestamps(); 
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('musicas');
    }
}
