@extends('layouts.app')

@section('template_title')
    {{ $produc->name ?? "{{ __('Show') Produc" }}
@endsection

@section('content')
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">{{ __('Show') }} Produc</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="{{ route('producs.index') }}"> {{ __('Back') }}</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Description:</strong>
                            {{ $produc->description }}
                        </div>
                        <div class="form-group">
                            <strong>Price:</strong>
                            {{ $produc->price }}
                        </div>
                        <div class="form-group">
                            <strong>Stock:</strong>
                            {{ $produc->stock }}
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
