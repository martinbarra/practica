<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('nombre')); ?>

            <?php echo e(Form::text('nombre', $cancione->nombre, ['class' => 'form-control' . ($errors->has('nombre') ? ' is-invalid' : ''), 'placeholder' => 'Nombre'])); ?>

            <?php echo $errors->first('nombre', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('artista, album')); ?>

            <?php echo e(Form::text('album', $cancione->album, ['class' => 'form-control' . ($errors->has('album') ? ' is-invalid' : ''), 'placeholder' => 'Artista, Album'])); ?>

            <?php echo $errors->first('album', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('fecha')); ?>

            <?php echo e(Form::date('fecha', $cancione->fecha, ['class' => 'form-control' . ($errors->has('fecha') ? ' is-invalid' : ''), 'placeholder' => 'Fecha'])); ?>

            <?php echo $errors->first('fecha', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group" style="display: none;">
            <?php echo e(Form::label('duracion')); ?>

            <?php echo e(Form::hidden('duracion', 1, ['id' => 'duracion'])); ?>

            <?php echo $errors->first('duracion', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('imagen')); ?>

            <?php echo e(Form::file('imagen', ['class' => 'form-control-file' . ($errors->has('imagen') ? ' is-invalid' : ''), 'placeholder' => 'Imagen'])); ?>

            <?php echo $errors->first('imagen', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('archivo')); ?>

            <?php echo e(Form::file('archivo', ['class' => 'form-control-file' . ($errors->has('archivo') ? ' is-invalid' : ''), 'placeholder' => 'Archivo'])); ?>

            <?php echo $errors->first('archivo', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary"><?php echo e(__('Submit')); ?></button>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\proyecto1\resources\views/cancione/form.blade.php ENDPATH**/ ?>