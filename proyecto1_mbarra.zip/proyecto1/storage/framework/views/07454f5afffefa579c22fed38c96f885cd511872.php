<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="text-center mb-4">
                    <h1 class="display-4"><?php echo e(__('InMusic')); ?></h1>
                </div>
                
                <?php if(auth()->guard()->check()): ?>
                    <div class="card">
                        <div class="card-header text-center">
                            <?php echo e(__('Bienvenid@')); ?> <?php echo e(Auth::user()->name); ?>

                        </div>

                        <div class="card-body">
                            <?php if(session('status')): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e(session('status')); ?>

                                </div>
                            <?php endif; ?>

                            <?php if(Auth::user()->email === 'admin@gmail.com'): ?>
                                <p><?php echo e(__('Si quieres acceder al panel de canciones, presiona el botón:   ')); ?>

                                <a href="<?php echo e(url('/canciones')); ?>" class="btn btn-primary"><?php echo e(__('Ir al Panel de Canciones')); ?></a></p>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
                
                <form action="<?php echo e(url('/home')); ?>" method="GET">
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" placeholder="Buscar canción" name="search" value="<?php echo e(request('search')); ?>">
                        <div class="input-group-append">
                            <button class="btn btn-outline-secondary" type="submit">Buscar</button>
                        </div>
                    </div>
                </form>

                <?php if($searchTerm): ?>
                    <p>Has buscado: "<?php echo e($searchTerm); ?>"</p>
                <?php endif; ?>

                <div class="container-fluid mt-4">
                    <div class="row">
                        <?php $__empty_1 = true; $__currentLoopData = $cancionesFiltro ?? $canciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cancione): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="card col-lg-4">
                                <img src="<?php echo e(asset('storage/images/' . $cancione->imagen)); ?>" class="card-img-top" alt="Imagen de la Canción">
                                <div class="card-body pb-5">
                                    <h5 class="card-title text-center"><?php echo e($cancione->nombre); ?> - <?php echo e($cancione->album); ?></h5>
                                    <?php echo e($cancione->likes_count); ?>


                                    <?php if(auth()->guard()->check()): ?>
                                        <?php if(!$cancione->likes->where('user_id', Auth::user()->id)->first()): ?>
                                            <a href="<?php echo e(url('liked/'.$cancione->id)); ?>" title="Like"> <span class="like" onclick="return true">🤍</span></a>
                                        <?php else: ?>
                                            <a href="<?php echo e(url('disliked/'.$cancione->id)); ?>" title="Dislike"> <span class="dislike" onclick="return true">❤️ </span></a>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <a href="<?php echo e(url('/login')); ?>" title="Ingresa para dar like"  > <span class="like">🤍</span></a>
                                    <?php endif; ?>

                                    <audio controls style="width: 100%; position: absolute; bottom:0; right: 0;">
                                        <source src="<?php echo e(asset('storage/files/' . $cancione->archivo)); ?>" type="audio/mpeg">
                                    </audio>
                                </div>
                            </div>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p>No se encontraron canciones.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if($cancionesFiltro): ?>
                    <?php echo e($cancionesFiltro->appends(request()->query())->links()); ?>

                <?php else: ?>
                    <?php echo e($canciones->appends(request()->query())->links()); ?>

                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyecto1\resources\views/home.blade.php ENDPATH**/ ?>